# Placement-and-higher-studies-app
An android application that could be used by students and faculty of an institution to see the placement details of the institution and also the details of the student gone for higher studies. Student can also feed their placement status by using the app that will be ones verified by the faculty advisor, with the help of app itself.
